import React from 'react';
import Login from '../components/Login';

const LoginPage = () => {
  return (
    <div>
      <h1>Bem-vindo ao Sistema de Administração</h1>
      <Login />
    </div>
  );
};

export default LoginPage;
